import random
import math


nook_inventory = {}
redd_inventory = {}

# 1 재고 시스템에 항목 입력
temp_inventory = []
while True:
    item = input('Add an item to the inventory list: ')
    if item == 'stop':
        print('\n--- Nook Inventory ---')
        for i in temp_inventory:
            print(i)
        break
    temp_inventory.append(item)


# 2 품목의 가격을 설정하고, 몇 가지 계산을 실행하십시오
print('\n')
for item in temp_inventory:
    price = input('[' + item + '] 가격을 입력하세요: ')
    nook_inventory[item] = int(price)

low_price = 1000000
high_price = 0
avg_price = 0

for price in nook_inventory.values():
    if price < low_price:
        low_price = price

    if price > high_price:
        high_price = price

    avg_price += price

avg_price = round(avg_price / len(nook_inventory), 3)
print('\n')
print('Low Price', low_price)
print('High Price', high_price)
print('Avg Price', avg_price)


# 3 Redd의 위조품 매장 설치
def markup(price):
    return math.floor(price + (random.random() * 35))


def discount(price):
    while True:
        discount_price = math.floor(price - (random.random() * 20))
        if discount_price >= 1:
            return discount_price


for item in nook_inventory.keys():
    price = nook_inventory[item]
    nook_or_redd = random.randrange(0, 3)
    if nook_or_redd == 1:
        redd_inventory[item] = markup(price)
    elif nook_or_redd == 2:
        redd_inventory[item] = discount(price)
    else:
        redd_inventory[item] = price

print('LOG > ', redd_inventory)
print('\nredd와의 가격 차이')
for item in nook_inventory.keys():
    nook_price = nook_inventory[item]
    redd_price = redd_inventory[item]
    print('[{}]: {}'.format(item, nook_price - redd_price))


# 4 당신의 가게 매출과 Redd의 가게 매출 비교
def random_item(inventory):
    items = list(inventory.keys())
    random_index = math.floor(random.random() * len(items))
    key = items[random_index]
    return { key : inventory[key] }


nook_customers = []
redd_customers = []
item_count = len(nook_inventory)

while True:
    buy_item_count = 0
    input_item_count = input('\n몇개의 품목을 구매할까요?(전체 품목수:{}) '.format(item_count))

    if 'stop' == input_item_count:
        break
    elif int(input_item_count) > item_count:
        print('등록된 품목보다 큰 수를 입력했습니다.')
        continue
    else:
        buy_item_count = int(input_item_count)

    for i in range(buy_item_count):
        nook_or_redd = random.randrange(0, 2)
        if nook_or_redd == 0:
            nook_customers.append(random_item(nook_inventory))
        else:
            redd_customers.append(random_item(redd_inventory))

def print_sell_items(customers):
    total_price = 0
    for sell_item in customers:
        item = list(sell_item.keys())[0]
        total_price += list(sell_item.values())[0]
        print('[{}] 판매'.format(item))
    print('총계: {}'.format(total_price))
    return total_price


print('\n--- Nook Customers ---')
nook_total = print_sell_items(nook_customers)

print('\n--- Redd Customers ---')
redd_total = print_sell_items(redd_customers)

if nook_total > redd_total:
    print('\nNook가 더 많은 돈을 벌었습니다')
elif nook_total < redd_total:
    print('\nRedd가 더 많은 돈을 벌었습니다')
else:
    print('\n같은 돈을 벌었습니다')


# 5 보너스: 두 스토어의 특정 항목 비교
def distinct_item(customers):
    result = set()
    for sell_item in customers:
        result.add(list(sell_item.keys())[0])
    return result


nook_sell_item_list = distinct_item(nook_customers)
redd_sell_item_list = distinct_item(redd_customers)
print('LOG > ', nook_sell_item_list)
print('LOG > ', redd_sell_item_list)

def difference(a, b):
    return a.difference(b)


nook_only_sell = difference(nook_sell_item_list, redd_sell_item_list)
redd_only_sell = difference(redd_sell_item_list, nook_sell_item_list)
print('LOG > ', nook_only_sell)
print('LOG > ', redd_only_sell)

if nook_sell_item_list == redd_sell_item_list:
    print('\n판매한 항목이 같습니다')
elif len(nook_only_sell) > 0:
    print('\nNook가 판매한 상품')
    for item in nook_only_sell:
        print(item)
else:
    print('\nNook가 판매하지 않은 상품')
    for item in redd_only_sell:
        print(item)
